    import { Request, Response } from "express";
    import { ResultSetHeader, RowDataPacket } from "mysql2";
    import pool from "../conf/dbConnection";

    interface ProductData {
    name: string;
    price: number;
    stock: number;
    description: string;
    brand: string | null;
    img: string | null;
    }

    function getId(idValue: unknown): number | null {
    if (typeof idValue !== "string") {
        return null;
    }

    const id = Number(idValue);

    if (!Number.isInteger(id) || id <= 0) {
        return null;
    }

    return id;
    }

    function getPrice(value: unknown): number | null {
    const price = Number(value);

    if (!Number.isFinite(price) || price <= 0) {
        return null;
    }

    return price;
    }

    function getProductData(body: unknown): ProductData | null {
    if (typeof body !== "object" || body === null) {
        return null;
    }

    const data = body as Record<string, unknown>;
    const price = getPrice(data.price);
    const stock = Number(data.stock);

    if (
        typeof data.name !== "string" ||
        data.name.trim() === "" ||
        price === null ||
        !Number.isInteger(stock) ||
        stock < 0 ||
        typeof data.description !== "string" ||
        data.description.trim() === ""
    ) {
        return null;
    }

    return {
        name: data.name.trim(),
        price,
        stock,
        description: data.description.trim(),
        brand: typeof data.brand === "string" ? data.brand.trim() || null : null,
        img: typeof data.img === "string" ? data.img.trim() || null : null
    };
    }

    export async function getAllProducts(_req: Request, res: Response): Promise<void> {
    try {
        const [products] = await pool.query<RowDataPacket[]>(
        "SELECT * FROM products WHERE active = TRUE"
        );

        res.status(200).json(products);
    } catch {
        res.status(500).json({ message: "No fue posible obtener los productos." });
    }
    }

    export async function getProductById(req: Request, res: Response): Promise<void> {
    const id = getId(req.params.id);

    if (id === null) {
        res.status(400).json({ message: "El id debe ser un entero positivo." });
        return;
    }

    try {
        const [products] = await pool.query<RowDataPacket[]>(
        "SELECT * FROM products WHERE id = ? AND active = TRUE",
        [id]
        );

        if (products.length === 0) {
        res.status(404).json({ message: "Producto no encontrado." });
        return;
        }

        res.status(200).json(products[0]);
    } catch {
        res.status(500).json({ message: "No fue posible obtener el producto." });
    }
    }

    export async function createProduct(req: Request, res: Response): Promise<void> {
    const product = getProductData(req.body);

    if (product === null) {
        res.status(400).json({ message: "Datos del producto inválidos." });
        return;
    }

    try {
        const [result] = await pool.query<ResultSetHeader>(
        `INSERT INTO products (name, price, stock, description, brand, img)
        VALUES (?, ?, ?, ?, ?, ?)`,
        [
            product.name,
            product.price,
            product.stock,
            product.description,
            product.brand,
            product.img
        ]
        );

        res.status(201).json({
        message: "Producto creado correctamente.",
        id: result.insertId
        });
    } catch {
        res.status(500).json({ message: "No fue posible crear el producto." });
    }
    }

    export async function updateProduct(req: Request, res: Response): Promise<void> {
    const id = getId(req.params.id);
    const product = getProductData(req.body);

    if (id === null || product === null) {
        res.status(400).json({ message: "Id o datos del producto inválidos." });
        return;
    }

    try {
        const [result] = await pool.query<ResultSetHeader>(
        `UPDATE products
        SET name = ?, price = ?, stock = ?, description = ?, brand = ?, img = ?
        WHERE id = ? AND active = TRUE`,
        [
            product.name,
            product.price,
            product.stock,
            product.description,
            product.brand,
            product.img,
            id
        ]
        );

        if (result.affectedRows === 0) {
        res.status(404).json({ message: "Producto no encontrado." });
        return;
        }

        res.status(200).json({ message: "Producto actualizado correctamente." });
    } catch {
        res.status(500).json({ message: "No fue posible actualizar el producto." });
    }
    }

    export async function deleteProduct(req: Request, res: Response): Promise<void> {
    const id = getId(req.params.id);

    if (id === null) {
        res.status(400).json({ message: "El id debe ser un entero positivo." });
        return;
    }

    try {
        const [result] = await pool.query<ResultSetHeader>(
        "UPDATE products SET active = FALSE WHERE id = ? AND active = TRUE",
        [id]
        );

        if (result.affectedRows === 0) {
        res.status(404).json({ message: "Producto no encontrado." });
        return;
        }

        res.status(200).json({ message: "Producto dado de baja correctamente." });
    } catch {
        res.status(500).json({ message: "No fue posible dar de baja el producto." });
    }
    }

    export async function changeProductPrice(req: Request, res: Response): Promise<void> {
    const id = getId(req.params.id);
    const price = getPrice(req.body?.price);

    if (id === null || price === null) {
        res.status(400).json({ message: "Id o precio inválido." });
        return;
    }

    try {
        const [result] = await pool.query<ResultSetHeader>(
        "UPDATE products SET price = ? WHERE id = ? AND active = TRUE",
        [price, id]
        );

        if (result.affectedRows === 0) {
        res.status(404).json({ message: "Producto no encontrado." });
        return;
        }

        res.status(200).json({ message: "Precio actualizado correctamente." });
    } catch {
        res.status(500).json({ message: "No fue posible cambiar el precio." });
    }
    }