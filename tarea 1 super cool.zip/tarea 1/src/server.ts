    import express, { Application } from "express";
    import routes from "./routes";

    class Server {
    public app: Application;

    constructor() {
        this.app = express();

        this.middlewares();
        this.routes();
    }

    private middlewares(): void {
        this.app.use(express.json());
    }

    private routes(): void {
        this.app.use("/api/v1", routes);
    }

    public listen(port: number): void {
        this.app.listen(port, () => {
        console.log(`Servidor ejecutándose en http://localhost:${port}`);
        });
    }
    }

    export default Server;